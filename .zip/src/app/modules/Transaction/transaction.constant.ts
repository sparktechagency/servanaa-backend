export const withdrawRequestSearchableFields = [
  'transactionId',  'type',  'contractorName',
];
