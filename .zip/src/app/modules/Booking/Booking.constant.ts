export const BOOKING_SEARCHABLE_FIELDS = [
  'userId',
  'providerId',
  'description',
  'isDeleted'
];



