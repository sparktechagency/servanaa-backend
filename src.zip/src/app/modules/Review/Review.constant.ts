export const REVIEW_SEARCHABLE_FIELDS = ['name', 'description', 'userId', 'star'];
