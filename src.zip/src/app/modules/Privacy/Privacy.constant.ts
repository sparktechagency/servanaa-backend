export const PRIVACY_SEARCHABLE_FIELDS = [ 'description'];
