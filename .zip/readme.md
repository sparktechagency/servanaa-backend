### Requirement Analysis

Date: 1/4/2025   2025/2026


Lists:

2 month
UI/UX
Mobile
Frontent
Backend
Devops

2 month
Cyber
Desktop
Project
SEO

next 8 month
Math
AI/ML
DSA
System D


books
fitness
SB
Quran
Arabic


april+may
1st slot:  frontend+UI/UX+Mobile
2nd slot:  backend+Devops+frontend
3rd slot: sleep+quran+arabic+fitness+Books

Next 
1st slot: Arabic+Quran+DSA+Math+System
2nd slot: SB+maintask+(SEO+Desktop+Project+Cyber+AI/ML)
3rd slot: Exercise+books

1. Full-Stack: Frontent+Backend+Database
2. Devops + System Design
3. DSA: datastructure & Algorithm
4. Cyber Security
5. Other: UI/UX, Mobile, Desktop, SEO, Project
6. Education: Math, English, Versity
7. AI/ML
8. High Profile

