export const REPORT_SEARCHABLE_FIELDS = ['userId.fullName', 'bookingId', 'subjectCategory'];
