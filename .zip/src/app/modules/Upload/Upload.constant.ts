export const UPLOAD_SEARCHABLE_FIELDS = ['name', 'description', 'atcCodes'];
