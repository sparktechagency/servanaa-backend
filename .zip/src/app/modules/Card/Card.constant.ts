export const CARD_SEARCHABLE_FIELDS = ['cardHolderName', 'cardNumber', 'cvvNo', 'expireDate'];
