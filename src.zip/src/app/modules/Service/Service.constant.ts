export const SERVICE_SEARCHABLE_FIELDS = ['requiredTasks', 'showSpecialists'];
