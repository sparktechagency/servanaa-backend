export const HELP_SEARCHABLE_FIELDS = ['userId', 'clientMessage', 'adminMessage'];
