export const CUSTOMER_SEARCHABLE_FIELDS = [
  'name',
  'dob',
  'city',
  'language',
  'location'
];



