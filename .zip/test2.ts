// const a = apiFromThirdparty();
// a.method();

// const b = apiFromOwnDatabase();
// b.method();

// c={
//     id:.....
// }

// d={
// _id:...
// }

// e={
//     _id:...
// }
// =============

// single booking

// recurringBooking