export const FAQ_SEARCHABLE_FIELDS = ['question', 'answer'];
