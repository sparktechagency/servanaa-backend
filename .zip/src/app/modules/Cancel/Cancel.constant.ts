export const CANCEL_SEARCHABLE_FIELDS = ['charge', 'description', 'message'];
