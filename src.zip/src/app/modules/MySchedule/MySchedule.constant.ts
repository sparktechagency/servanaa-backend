export const MYSCHEDULE_SEARCHABLE_FIELDS = ['day','userId'];
export const daysOfWeek  = [
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday',
      'Sunday',
    ];