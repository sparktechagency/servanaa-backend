export const TERM_SEARCHABLE_FIELDS = ['name', 'description', 'atcCodes'];
