export const CONTRACTOR_SEARCHABLE_FIELDS = [
  'skillsCategory',
  'skills',
  'materials',
  'subscriptionId'
];




