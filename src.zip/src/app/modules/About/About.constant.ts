export const ABOUT_SEARCHABLE_FIELDS = [ 'description'];
