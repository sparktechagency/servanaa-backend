export const MATERIAL_SEARCHABLE_FIELDS = ['name', 'unit', 'price'];
