export const SUBCATEGORY_SEARCHABLE_FIELDS = ['name', ];
