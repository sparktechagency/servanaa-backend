export const CHATROOM_SEARCHABLE_FIELDS = ['participants'];
