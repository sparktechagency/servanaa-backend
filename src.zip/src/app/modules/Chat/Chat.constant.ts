export const CHAT_SEARCHABLE_FIELDS = ['message'];
